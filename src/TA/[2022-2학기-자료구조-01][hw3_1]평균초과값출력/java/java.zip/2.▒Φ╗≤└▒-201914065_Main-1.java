import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);  //Scanner import
		System.out.println("hw3_1 : 김상윤");
		
		System.out.print("정수 개수 입력 : ");
		int N = scan.nextInt(); 		//정수 개수를 int로 입력받습니다.
		
		System.out.print(N + "개의 정수값 입력 : ");
		int arr[] = new int[N];		//정수 배열을 생성하고 입력받은 정수들을 저장합니다.
		for(int i=0; i<N; i++) {
			arr[i] = scan.nextInt();
		}

		double avg = 0;        	              //평균avg를 구하기위해 배열의 총합을 구해서 정수의 개수와 나눕니다.
		for (int i = 0; i < N; i++) {
			avg += arr[i];
		}
		avg /= N;
		
		System.out.println("평균 = " + avg);  
		System.out.print("평균 초과 =");
		
		for(int i=0; i<N; i++) {   
			if(arr[i]>avg) {  		//배열의 값이 평균보다 크면 출력합니다.
				System.out.print(" " + arr[i]);
			}
		}
		scan.close();
	}
}
