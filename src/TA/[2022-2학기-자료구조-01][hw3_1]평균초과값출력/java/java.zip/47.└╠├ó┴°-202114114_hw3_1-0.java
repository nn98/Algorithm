package hw3_1;

import java.util.Scanner;

public class hw3_1 {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("hw3_1 : ��â��");
		System.out.print("���� ���� �Է�: "); 

		int count = input.nextInt();

		int[] arrayTest = new int[count];


		System.out.println(count+"���� ���� ��: ");
		for (int i = 0; i < count; i++) {
			arrayTest[i] = input.nextInt();

		}

		int sum = 0;
		for (int num : arrayTest) {

			sum += num;

		}

		double avg = (double)sum/arrayTest.length;

		System.out.println("���= " + avg);

		System.out.print("��� �ʰ���= ");

		for (int i = 0; i < arrayTest.length; i++) {

			if(arrayTest[i]>avg)

				System.out.print(arrayTest[i]+ " ");        

		}





	}

}

