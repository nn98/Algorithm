import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int sum = 0; // 입력받을 정수들의 합을 저장할 변수 초기화
		
		System.out.println("hw3_1 : 최지연");
		System.out.print("정수의 개수 입력 : ");
		int n = input.nextInt(); //n은 정수의 개수
		int[] array = new int[n]; //정수들을 저장할 배열 array

		System.out.print(n + "개의 정수값 입력 : ");
		for(int i=0;i<n;i++) {
			array[i] = input.nextInt();
			sum = sum + array[i]; 
		}
		float average = (float)sum / (float)n; //평균을 실수로 출력하기위해 sum과 n을 float형으로 지정
		System.out.println("평균 = " + average);
		
		System.out.print("평균 초과 = ");
		for(int j=0;j<n;j++) {
			if (array[j] > average)
				System.out.print(array[j]+" "); // 정수들의 평균을 초과하는 값만 출력
		}
	}

}
