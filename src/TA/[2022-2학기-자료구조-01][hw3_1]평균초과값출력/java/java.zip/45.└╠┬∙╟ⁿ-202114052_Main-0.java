package hw3_1;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	   public static void main(String[] args) {
	      System.out.println("hw3_1 : 이찬형"); //hw3_1 : 이찬형 출력 
		   
	      Scanner input = new Scanner(System.in); //스캐너 선언
	      
	      System.out.print("정수 개수 입력 : ");
	      int number = input.nextInt(); //정수 개수에 해당하는 값을 변수에 입력받음
	      
	      int[] arr1 = new int[number]; //정수 문자열 선언 
	      int[] arr2 = new int[number];
	      Arrays.fill(arr1, 0); //정수 문자열을 0으로 초기화
	      Arrays.fill(arr2, 0);
	      double sum = 0; //실수형 변수 선언
	      double average = 0;
	      System.out.print(number + " 개의 정수값 입력 : ");
	      
	      for(int i=0 ; i < number ; i++) { //반복문을 통해 정수 문자열에 정수값 입력받음
	    	  arr1[i] = input.nextInt();
	    	  sum += arr1[i]; //평균 계산을 위한 총 합계 계산
	      }
	      average = sum / number; //평균 계산
	      for(int j=0;j<number;j++) { //반복문 속 조건문을 통해서 평균을 초과하는 값 식별
	    	  if(average < arr1[j]) {
	    		  arr2[j] += arr1[j];
	    	  }
	      }
	      System.out.println("평균 = " + average); //계산한 것들을 출력 
	      System.out.print("평균값 초과 =");
	      for(int j=0;j<number;j++) { //반복문 속 조건문을 통해서 평균을 초과하는 값 출력 
	    	  if(arr2[j] != 0) {
	    		  System.out.print(" " + arr2[j]);
	      }
	   }
	}
}
