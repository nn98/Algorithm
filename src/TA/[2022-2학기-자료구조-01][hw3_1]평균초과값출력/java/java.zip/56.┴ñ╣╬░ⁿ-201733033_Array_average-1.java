package hw3_1;

import java.util.Scanner;

public class Array_average {

		public static void main(String[] args) {

		System.out.println("hw3_1 : 정민관");
		Scanner input = new Scanner(System.in);
		System.out.println("정수 개수 입력 :");

		int number = input.nextInt();
		System.out.print(number + "개의 정수값 입력 : ");
		int[] numberArray = new int[number];
		int sum = 0;

		for (int i = 0; i < number; i++) {
			numberArray[i] = input.nextInt();
			sum += numberArray[i];
		}

		double average = sum / (double) number;

		System.out.println("평균 =" + average);
		System.out.print("평균 초과 = ");

		for (int i = 0; i < number; i++) {
			if (average < numberArray[i])
				System.out.print(numberArray[i] + " ");
		}

	}

}