package hw3_1;
import java.util.*; // 스캐너를 사용하기 위해서 

public class OverAverage { // 평균값과 평균값보다 큰 값들을 출력하는 클래스 
	public static void main(String[] args) {
		System.out.println("hw3_1 : 박세연"); // 이름 출력

		Scanner s = new Scanner(System.in); // 새로운 스캐너 s 생성하기

		System.out.print("정수 개수 입력 : ");
		int n=s.nextInt(); // 사용자에게 정수(정수 개수) 입력받기
		final int N = n; // 기호상수 선언
		int num[] = new int [N]; // 배열 생성, 요소의 개수는 N개

		System.out.print(n+"개의 정수값 입력 : "); // 사용자로부터 n개의 정수값 입력받기
		for(int i=0;i<n;i++) { // i가 0부터 n이 되기 전까지 1씩 증가하며 반복
			num[i]=s.nextInt(); // 사용자로부터 정수 입력받기
		}

		double sum=0; // 변수 sum(입력받은 수들의 합을 저장할 변수) 선언 및 초기화

		for(int i=0;i<n;i++) { // i가 0부터 n이 되기 전까지 1씩 증가하며 반복
			sum+=num[i]; // sum에 sum+num[i]의 값 대입하기
		}

		double avg=sum/n; // 변수 avg(입력받은 수들의 평균을 저장할 변수) 선언 및 초기화
		/*
		 여기서 주의! 정수/정수의 값은 정수로 나온다! 따라서 sum을 실수로 만들거나, 형변환을 시켜줘야 한다!
		 */
		System.out.println("평균 = "+avg); // 평균값 출력하기

		System.out.print("평균 초과 = ");
		for(int i=0;i<n;i++) { // i가 0부터 n이 되기 전까지 1씩 증가하며 반복
			if(num[i]>avg) { // 만약, num[i]의 값이 avg의 값보다 크다면
				System.out.print(num[i]+" "); // 평균을 초과하는 정수들 출력하기
			}
		}

		s.close(); // 스캐너 s 닫기
	}

}

