package hw3_1;

import java.util.Scanner;

public class hw3_1 {
	public static void main(String[] args) {
		System.out.println("hw3_1 : 김승욱");
		// 정수 개수(n) 입력받기
		System.out.print("정수 개수 입력 : ");
		Scanner s1 = new Scanner(System.in);
		int n = s1.nextInt();
		// n개의 정수값을 입력받기
		System.out.print(n+"개의 정수값 입력 : ");
		Scanner s2 = new Scanner(System.in);
		// 입력받은 정수값을 배열에 저장하기
		int Array[] = new int[n]; // 길이가 n인 정수형 배열 Array 생성
		for (int i=0; i<n; i++) {
			Array[i] = s2.nextInt();
		}
		// 평균 구하기
		int sum = 0; // 총합을 구하기 위한 변수 sum
		for (int j=0; j<n; j++) {
			sum = sum + Array[j];
		}
		double avg = sum / (double)n;
		System.out.println("평균 = "+avg);
		// 평균보다 큰 값 구하기
		System.out.print("평균 초과 = ");
		for (int k=0; k<n; k++) {
			if (Array[k] > avg)
				System.out.print(Array[k]+" ");
		}
	}
}