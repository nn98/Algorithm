package homeworks;

import java.util.Scanner;

public class AverageNumber {
	public static void main(String[] args) {
		int avg = 0;
		System.out.println("hw3_1 : �̹ο�");
		Scanner count = new Scanner(System.in);
		System.out.print("���� ���� �Է� : ");
		int cnt = count.nextInt();
		Scanner input = new Scanner(System.in);
		int[] num = new int[cnt];
		System.out.println(cnt + "���� ������ �Է� : ");
		for(int i = 0; i < num.length; i++) {
			num[i] = input.nextInt();
		}
		for(int i = 0; i < num.length; i++) {
			avg += num[i];
		}
		
		System.out.println("��� : " + (double) avg / num.length);
		System.out.print("����ʰ� :");
		for(int i = 0; i < num.length; i++) {
			if(num[i] > avg / num.length) {
				System.out.print(num[i] + " ");
			}
		}
	}	
}