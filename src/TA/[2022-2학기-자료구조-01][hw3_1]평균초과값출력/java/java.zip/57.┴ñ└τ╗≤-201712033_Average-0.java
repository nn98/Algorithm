package dataStructure;
import java.util.Arrays;
import java.util.Scanner;

public class Average  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);

		System.out.println("hw3_1 : 정재상");
		
		System.out.print("정수 개수 입력: ");
		int numOfInput = input.nextInt();
		
		int[] arr = new int[numOfInput];
		double average = 0;
		double sum = 0;
		
		System.out.print(numOfInput+"개의 정수값 입력 : ");
		
		for(int i = 0; i<arr.length; i++) {
			int element = input.nextInt();
			arr[i] = element;
			sum = sum+element;
		}
		
		average = sum/arr.length;
		
		System.out.println("평균 = "+average);
		
		System.out.print("평균초과 = ");
		
		for(int i = 0; i<arr.length; i++) {
			if(arr[i]>average) {
				System.out.print(arr[i]+" ");
			}
		}
		
	}

}
