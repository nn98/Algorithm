package hw3_1;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); //scanner 객체 생성

		System.out.println("hw3_1 : 박지민");
		System.out.print("정수 개수 입력:");
		int x = input.nextInt();  // 입력 받을 정수 개수 x
		int inputX[]=new int[x];

		System.out.print(x + "개의 정수를 입력하세요:");
		for(int i=0; i<x; i++) {
			inputX[i]=input.nextInt();
		}

		double Sum=0;
		double average =0;  // 평균

		for(int i=0; i<x; i++) {
			Sum=inputX[i]+Sum;

		} // 합계 구하기

		average=Sum/x; // 평균 구하기

		System.out.println("평균:"+ average);
		System.out.print("평균 초과:");
		for(int i=0; i<x; i++) {
			if(inputX[i]>average) {
				System.out.print(" "+inputX[i]+" "); 
			}
			// 반복문을 통해서 배열의 원소들을 평균과 비교해서 평균보다 큰 원소들 출력
		}


	}

}
