package hw3_1;

import java.io.*;
import java.util.StringTokenizer;

public class AverageOverNumber {
    public static void main(String[] args) throws IOException {
        //입출력용 객체
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

        //정수의 개수 입력부
        System.out.println("hw3_1 : 이한길");
        System.out.print("정수 개수 입력 : ");
        int n = Integer.parseInt(br.readLine()); //정수의 개수를 저장할 변수
        int[] numberArr = new int[n]; //입력받은 n개의 정수를 저장할 변수
        int sum = 0; //정수의 합계를 저장할 변수

        //n개의 정수 입력, 저장, 합산부
        System.out.print(n + "개의 정수값 입력 : ");
        StringTokenizer st = new StringTokenizer(br.readLine());
        for(int i = 0; i < n; i++) {
            int currentNum = Integer.parseInt(st.nextToken());
            numberArr[i] = currentNum;
            sum += currentNum;
        }

        //평균 연산 및 출력부
        double average = (double)sum / n;
        System.out.println("평균 = " + average);

        //평균 초과의 정수 출력부
        System.out.print("평균 초과 = ");
        for(int i = 0; i < n; i++) {
            if(numberArr[i] > average) {
                bw.write(numberArr[i] + " ");
            }
        }
        bw.flush();
        bw.close();
        br.close();
    }
}
