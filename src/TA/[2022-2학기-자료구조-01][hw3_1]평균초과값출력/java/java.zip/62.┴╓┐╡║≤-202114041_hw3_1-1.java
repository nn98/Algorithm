import java.util.Scanner;

public class hw3_1 {
	public static void main(String[] args) {
		System.out.println("hw3_1 : 주영빈");
		Scanner scanner = new Scanner(System.in);
		
		int sumArray = 0;
		System.out.print("정수 개수 입력: ");
		int	arrayNumber = scanner.nextInt();
		int[] intArray = new int[arrayNumber];
		
		System.out.print(arrayNumber + "개의 정수값 입력: ");
		for(int i = 0; i < intArray.length; i++) {
			intArray[i] = scanner.nextInt();
			sumArray += intArray[i];
		}
		
		double average = sumArray / intArray.length;
		System.out.println("평균: " + average);
		
		System.out.print("평균 초과: ");
		for(int j = 0; j < intArray.length; j++) {
			if (intArray[j] > average) {
				System.out.print(intArray[j] + " ");
			}
			else {
				continue;
			}
		}
	}
}
