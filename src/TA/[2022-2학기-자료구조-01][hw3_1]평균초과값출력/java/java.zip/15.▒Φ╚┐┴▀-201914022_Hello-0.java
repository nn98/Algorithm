package lab0_1;
import java.util.Scanner;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//n개의 정수값을 입력받아 배열에 저장한 후,
		//이 값들 중에서 이들의 평균값보다 큰 값들을 모두 출력하세요.

		System.out.println("hw3_1 : 김효중");

		System.out.println("정수 개수 입력 : ");
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int[] arr = new int[n];
		double sum = 0;
		System.out.println(n+"개의 정수 값 입력 :");
		for(int i = 0;i<n;i++) {
			Scanner element = new Scanner(System.in);
			arr[i] = element.nextInt();
			sum += arr[i];
		}
		sum /= n;
		System.out.println("평균 = "+sum);


		int[] is_over = new int[n];
		int first_index = 0;
		for(int i = 0;i<n;i++) {
			if(arr[i] > sum) {
				is_over[first_index] = arr[i];
				first_index++;
			}
		}
		System.out.print("평균 초과 = ");
		for(int i = 0;i<first_index;i++) {
			System.out.print(is_over[i] + " ");
		}


	}


}
