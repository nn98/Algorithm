package hw3_1;
import java.util.Scanner;

public class AvgPrint {
	public static void main(String[] args) {
		System.out.println("hw3_1 : 조정호"); 
		Scanner input = new Scanner(System.in);//입력 스캐너 생성
		int[] arr;//입력받은 숫자를 담을 크기가 정해지지 않은 배열 선언
		double sub = 0;//숫자들의 총합을 담을 실수형 sub
		
		System.out.print("정수 개수 입력: "); 
		int size = input.nextInt();//스캐너 input을 통한 size 값 입력
		arr = new int[size];//배열의 크기를 입력받은 값으로 지정
		
		System.out.print(size + "개의 정수값 입력: "); //배열의 크기만큼 반복 진행
		for (int i = 0 ; i < size ; i++) {
			arr[i] = input.nextInt();//스캐너 input을 통한 각각 배열의 내용값 입력
			sub += arr[i]; //동일 규격의 반복문을 이용하여 총합 sub에 각각 배열에 담긴 값을 합산

		}
	
		System.out.println("평균: " + sub/size); //평균 출력
		System.out.print("평균초과: "); 

		for (int i = 0 ; i < size ; i++) {//평균을 초과하는 값을 골라내는 반복문
			if (arr[i] > sub/size) {
				System.out.print(arr[i]);
				System.out.print(' ');//가독성을 위한 빈칸
			}
		}
		input.close();//입력스캐너 input close
	}

}
