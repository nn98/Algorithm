package hw3_1;
import java.util.Arrays;
import java.util.Scanner;
public class hw3_1 {
	public static void main(String[]args) {
		Scanner input= new Scanner(System.in);
		System.out.println("hw3_1:���¿�");
		System.out.println("���� ���� �Է�");
		int a= input.nextInt();
		int[] nums = new int[a];
		float avg=0;
		float sum=0;
		int over_avg=0;
		System.out.println(a+"���� ���� �Է�:");
		for(int i=0; i<nums.length; i++) {
			nums[i] = input.nextInt();
			sum= sum+nums[i];	
		}
		avg=sum/(nums.length);
		System.out.println("���="+avg);	
		System.out.print("��� �ʰ�=");
		for(int j=0; j<nums.length; j++) {
			if(avg<nums[j]) {
				over_avg=nums[j];
				System.out.print(over_avg+" ");
			}
		}	
	}

}
