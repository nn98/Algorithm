package Main;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args) 
	{
		System.out.println("hw3_1 : 천정명");
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("정수 개수 입력 : ");
		int n = input.nextInt();
		int[] array = new int[n];
		double sum = 0;
		
		System.out.print("10개의 정수값 입력 : ");
		for(int i =0; i < n; i++)
		{
			array[i] = input.nextInt();
			sum += array[i];
		}
		double avg = sum / n;
		System.out.println("평균 = "+avg);
		
		System.out.print("평균 초과 = ");
		for(int element:array)
		{
			if(element>avg)
			{
				System.out.print(element+" ");
			}
		}
	}
}
