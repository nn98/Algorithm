package hw3_1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// 스캐너 호출
		Scanner scanner = new Scanner(System.in);
		System.out.println("hw3_1 : 문상혁");
		System.out.print("정수 개수 입력: ");
		// 정수 개수 입력
		int length = scanner.nextInt();
		// 배열 생성
		int[] numbers = new int[length];
		System.out.print(length + "개의 정수값 입력: ");
		// 배열의 인덱스에 입력 받은 정수 값을 입력
		for (int i = 0; i < length; i++) {
			numbers[i] = scanner.nextInt();
		}
		float sum = 0;
		// 배열의 총합
		for (int i = 0; i < length; i++) {
			sum += numbers[i];
		}
		// 배열의 평균값 구하기
		float average = sum / length;
		System.out.println("평균 = " + average);
		System.out.print("평균초과 = ");
		// 평균을 초과한 정수들을 구하기
		for (int i = 0; i < length; i++) {
			if (numbers[i] > average) {
				System.out.print(numbers[i] + " ");
			}
		}
		scanner.close();
	}
}
