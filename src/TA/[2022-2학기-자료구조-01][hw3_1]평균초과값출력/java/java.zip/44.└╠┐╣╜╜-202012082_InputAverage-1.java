import java.util.Scanner;


public class InputAverage{
	public static void main(String[] args) {
		//이름 입력
		System.out.println("hw3_1: 이예슬");
		// 두 정수를 입력받아 합을 출력
		Scanner input = new Scanner(System.in);
		System.out.print("정수 개수 입력 : ");
		int count = input.nextInt();	//정수변수 num에 정수를 입력받는다.
		System.out.print("10개의 정수값 입력 : ");
		int[] arr = new int[count];
		int num = 0;
		double avg=0;
		double sum=0;
		int[] avgover= new int[count];
		for(int i=0; i<count; i++) {
			arr[i]=input.nextInt();
			sum = sum +arr[i];
			avg= sum/count;
		}
		System.out.println("평균 = "+ avg);
		for(int i=0; i<count; i++) {
			if(arr[i]>avg) {
				avgover[i]=arr[i];
			}
		}
		System.out.print("평균 초과 = ");
		for(int i=0; i<arr.length; i++) {
			if(avgover[i]>avg){
				System.out.print(avgover[i]+" ");
			}
		}
	}
}
