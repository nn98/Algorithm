package hw3_1;
import java.util.Scanner;

public class hw3_1 {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		System.out.println("hw3_1 : 김창현");

		// 정수 개수 입력
		System.out.print("정수 개수 입력: ");
		int num = sc.nextInt();

		// 정수값 입력
		int[] score = new int[num];
		System.out.print(num+"개의 정수값 입력: ");
		for(int i=0; i<score.length; i++) {
			score[i] = sc.nextInt();
		}

		// 평균
		for(int i=0; i<score.length; i++) {
			sum += score[i];			
		}
		int aver = sum/num;
		System.out.println("평균 = " + aver);

		// 평균 초과
		System.out.print("평균 초과 = ");
		for(int i=0; i<score.length; i++) {
			if(score[i]>aver) {
				System.out.print(score[i]+ " ");

			}
		}
	}
}