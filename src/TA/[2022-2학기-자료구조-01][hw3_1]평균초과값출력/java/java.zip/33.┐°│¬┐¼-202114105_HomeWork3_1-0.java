package hw3_1;

import java.util.Scanner;

public class HomeWork3_1 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); // 스캐너 열기

		System.out.println("hw3_1 : 원나연"); // 과제코드와 본인 이름 출력하기

		// 1. 사용자가 정수의 개수(numberOfIntegers) 입력하기
		System.out.print("정수 개수 입력 : "); // 안내문 출력
		int numberOfIntegers = sc.nextInt(); // 정수의 개수 입력

		// 2. 정수의 개수만큼 정수를 입력받기
		System.out.print(numberOfIntegers + "개의 정수값 입력 : "); // 안내문 출력
		int[] integers = new int[numberOfIntegers]; // 정수를 저장할 배열 integers 생성, 정수의 개수(numberOfIntegers)만큼 배열의 길이를 지정

		// 정수를 저장할 배열(integers)에 정수를 입력
		for (int i = 0; i < numberOfIntegers; i++) {
			integers[i] = sc.nextInt();
		}

		// 3. 평균 구하기
		double sumOfIntegers = 0; // 사용자로부터 입력받은 정수의 합인 sumOfIntegers 변수 초기화
		double averageOfIntegers = 0; // 사용자로부터 입력받은 정수의 평균인 averageOfIntegers 변수 초기화

		// 배열 integers에 있는 모든 정수를 정수의 합(sumOfIntegers)에 저장
		for (int i = 0; i < integers.length; i++) {
			sumOfIntegers = sumOfIntegers + integers[i];
		}

		averageOfIntegers = sumOfIntegers / integers.length; // 평균 = 모든 합 / 총 개수(= 배열의 길이)
		System.out.println("평균 = " + averageOfIntegers); // 평균 출력

		// 4. 평균보다 초과하는 값 구하기
		System.out.print("평균 초과 = "); // 평균 초과 안내문 출력

		// 평균과 배열 integers에 있는 수를 비교하였을 때, 만약, 배열에 있는 수가 더 크다면 배열에 있는 수를 출력
		for (int j = 0; j < integers.length; j++) {
			if (averageOfIntegers < integers[j]) {
				System.out.print(integers[j] + " ");
			}
		}

		sc.close(); // 스캐너 닫기
	}
}