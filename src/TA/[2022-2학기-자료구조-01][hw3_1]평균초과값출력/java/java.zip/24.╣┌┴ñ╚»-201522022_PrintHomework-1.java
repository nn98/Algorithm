import java.util.Scanner;
public class PrintHomework {
    public static void main(String[] args){
   System.out.println("hw3_1 : 박정환");
        Scanner input = new Scanner(System.in);// 스캐너 추가
        System.out.println("정수 개수 입력 : ");
        int a= input.nextInt();                 //정수 개수 입력
        int[] numbers =new int[a];              //입력받은 정수 개수 적용
        System.out.print("정수 입력 : ");

        for(int i=0; i<a ; i++){
            numbers[i] = input.nextInt();       //임의의 정수 입력
        }
        int sum =0;
        double avg=0;
        for (int i = 0; i< numbers.length; i++){    //총합 연산
            sum+=numbers[i];
        }
        avg=sum/(double) numbers.length;            //형균 연산
        System.out.println("평균 : ");
        System.out.println(avg);                    //평균 출력
        System.out.print("초과 : ");
        for (int i = 0; i< numbers.length; i++){    //배열에서 초과만 출력
            if (numbers[i]>avg){
                System.out.print(numbers[i]+" ");
            }
        }
    }
}
