import java.util.Scanner;

public class average {
	public static void main(String[] args) {
		System.out.println("HW3_1 : 홍성산");
	 
		// HW3_1 코드
		double total = 0.0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("입력 할 수의 개수 : ");
		int n = sc.nextInt();
		
		int[] num = new int[n];
		
		System.out.print("입력 받을 수 : ");
		
		for(int i = 0; i < n; i++) { 
			num[i] = sc.nextInt();  // 숫자 입력
			if(num[i] > 100 || num[i] < 0) {
				System.out.println("오류 발생. 재입력");
				i--; // 0미만 또는 100이상 입력시 재입력 하도록 설정.
				continue;
			}

		}
		
		for(int i = 0; i < n; i++) {
			total += num[i];
		}
		
		double avg = total/n ;
		
		System.out.println("입력한 수의 평균: " +avg);
		
		System.out.print("평균 초과: " );
		
		for(int i=0; i<n; i++) {
			if(avg < num[i]){	
				System.out.print(num[i]+ " ");
			}
			
		}
			
		}
		
		
	}
