package hw3_1;

import java.util.Scanner;

public class Average { 
  public static void main(String[] args) {
        System.out.println("hw3_1 : 현진용");

        /*정수의 개수를 입력받고 받은 값으로 배열의  길이를 정함. */
        System.out.printf("정수 개수 입력 : ");
        Scanner input = new Scanner(System.in);
        int intNum = input.nextInt();
        int[] intNumber = new int[intNum];

        System.out.printf(intNum+"개의 정수값 입력 : ");
        for(int i=0;intNum>i; i++) {
            intNumber[i] = input.nextInt();
        }
        input.close();
        /*평균과 평균 초과 출력*/
        int sum = 0;
        for (int a=0; intNum>a; a++) {
            sum=sum+intNumber[a];
        }
        float result = sum/intNumber.length;
        System.out.println("평균 : "+result);

        System.out.print("평균 초과 : ");
        for (int i = 0; i < intNum; i++) {
            if (intNumber[i]>result) {
                System.out.print(intNumber[i]+" ");
            }
        }
    }
}
