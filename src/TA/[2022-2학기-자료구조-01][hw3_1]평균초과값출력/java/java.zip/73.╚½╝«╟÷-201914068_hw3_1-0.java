package hw3_1;
import java.util.Scanner;

public class hw3_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("hw3_1 : ȫ����");
		System.out.print("���� ���� �Է� : ");
		int a = sc.nextInt();
		System.out.print(a + "���� ������ �Է� : ");
		int [] numbers = new int [a];
		for(int i=0; i<numbers.length; i++) {
			numbers[i] = sc.nextInt();
		}
		double b = 0;
		double c = 0;
		for(int i=0; i<numbers.length; i++) {
			b = b + numbers[i];
		}
		c = b/a ;
		System.out.println("��� = " + c);
		System.out.print("��� �ʰ� = " );
		for(int i=0; i<numbers.length; i++) {
			if(c < numbers[i]) {
				System.out.print(numbers[i] + " ");
			}
		}
		
		
	}
}
